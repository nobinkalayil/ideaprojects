import driver.Drivermanager;
import org.junit.Test;
import pagefactor.Locator;

import java.util.List;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.core.Every.everyItem;
public class RegressionSuit extends Hooks {



    Locator locator = new Locator();

    @Test
    public void productReviewrating() {

        locator.searchproduct("nike");
        locator.linktext("GOT IT");
          locator.selectRevieRating("4or more");
            locator.selectPricerate("£10 - £15");
            locator.getAllRating();
            locator.getPriceRating();
        List<Double> priceRate = locator.getPriceRating();

        List<Double> actual = locator.getAllRating();

        System.out.println(actual);


        assertThat(actual, everyItem(greaterThan(4.0)));
        assertThat(priceRate, everyItem(greaterThan(11.0)));
        assertThat(priceRate,everyItem(lessThanOrEqualTo(21.0)));
        assertThat(priceRate, everyItem(greaterThanOrEqualTo(5.0)));



        }
    }


