package driver;

import io.github.bonigarcia.wdm.ChromeDriverManager;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

import static io.github.bonigarcia.wdm.WebDriverManager.chromedriver;

public class Drivermanager {
    public static WebDriver driver;
    private String browser = "";
    public void openbrowser(String browserType){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();

    }
   public void navigate(String url){driver.get(url);
   }
    public void maximisebrowser(){driver.manage().window().maximize();}

   public void waitdriver(){driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);}
 public void handleAppCookies(){driver.findElement(By.linkText("GOT IT"));}

 public void closebrowser(){driver.quit();}
    public void sleep(int milli) {
        try {
            Thread.sleep(milli);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
